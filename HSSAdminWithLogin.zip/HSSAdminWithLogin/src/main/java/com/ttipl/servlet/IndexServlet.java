package com.ttipl.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ttipl.DBConfig.DBConfiguration;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 

@WebServlet("/indexServlet")
public class IndexServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	//to get count of male and female - who have completed applying for the post
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 		 
		 String username = request.getParameter("username");
		 String password = request.getParameter("password");
		 HttpSession session = request.getSession();
		 session.setAttribute("admin", username);
		 
		 System.out.println(username + password);
		 PrintWriter out = response.getWriter();
		 
		 if(username.equals("admin") && password.equals("adminhssc@123")) {
			 System.out.println("Entered");
			  request.getRequestDispatcher("index.jsp").forward(request, response);
		 }
		 else {
			 System.out.println("Invalid");
			 request.setAttribute("errorMessage", "Invalid credentials");
			 request.getRequestDispatcher("loginPage.jsp").forward(request, response);
		 } 
            
    }
	

}
