
package com.ttipl.servlet;

	import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ttipl.DBConfig.DBConfiguration;
import com.ttipl.bean.Applicant;
import com.ttipl.bean.AppliedPosts;
import com.ttipl.bean.EducationalDetails;
import com.ttipl.bean.ExperienceDetails;
import com.ttipl.bean.SocioEconomic;
	 

	@WebServlet("/detailsServlet")
	public class DetailsServlet extends HttpServlet {
		private static final long serialVersionUID = 1L; 
		
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			 
			response.setContentType("text/html");
	        PrintWriter out = response.getWriter(); 
	        Connection conn = null;
	        Statement tid = null;
	        Statement st = null;
	        
	        Statement edet = null;
	        Statement sEc = null;
	        
	        Statement sExpc = null;
	        Statement sAp = null;
	        
	        try {
	        conn = 	DBConfiguration.Initialize();
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}  
	        try {  
	        	
	        	String id = request.getParameter("tid");
	        	st = conn.createStatement();
	            String query = "SELECT * FROM applicants WHERE transactionid='"+id+"';";
	            
	            System.out.println(query);
	            ResultSet rId = st.executeQuery(query);
	           
	             List<Applicant> appTid = new ArrayList<>();	             
	         while(rId!=null && rId.next()) {
	            	  
	            	 Applicant applicantTId = new Applicant();
	            	 applicantTId.setTid(rId.getString(1));
	            	 	            	 
	            	 	String firstName = rId.getString(2);
		            	firstName = firstName.substring(0,1).toUpperCase() + firstName.substring(1).toLowerCase();
		            	applicantTId.setFirstName( firstName);
		            	
		                String middleName = rId.getString(3);	
		                if(middleName!=null)
		                middleName = middleName.toLowerCase();
		                applicantTId.setMiddleName( middleName);
		                
		                String lastName = rId.getString(4);
		                if(lastName!=null)
		                lastName = lastName.toLowerCase();
		                applicantTId.setLastName( lastName);
	            	  
		                applicantTId.setFullName( rId.getString(5));
	            	 
	            	 
	            	 	String fatherName = rId.getString(6);
		            	fatherName = fatherName.substring(0,1).toUpperCase() + fatherName.substring(1).toLowerCase();
		            	applicantTId.setFatherName(fatherName);
	            	 
		            	String motherName = rId.getString(7);
		            	motherName = motherName.substring(0,1).toUpperCase() + motherName.substring(1).toLowerCase();
		            	applicantTId.setMotherName(motherName);
 
		            	applicantTId.setMobile(rId.getString(9));
		            	applicantTId.setEmail(rId.getString(10));
		            	applicantTId.setGender(rId.getString(12));
		            	applicantTId.setDob(rId.getString(13));
		            	applicantTId.setCategory(rId.getString(16));
		            	applicantTId.setMaritalStatus(rId.getString(19));
		            	
		            	String desm = rId.getString(27);
		            	if(desm.equalsIgnoreCase("1")) {
		            		applicantTId.setDesm("Yes");
		            	}else {
		            		applicantTId.setDesm("No");
		            	}
		            	
		            	
		            	String isDdesm = rId.getString(28);
		            	if(isDdesm.equalsIgnoreCase("1")) {
		            		applicantTId.setIsDdesm("Yes");
		            	}else {
		            		applicantTId.setIsDdesm("No");
		            	} 
		            	
		            	
		            	String isPH = rId.getString(30);
		            	if(isPH.equalsIgnoreCase("1")) {
		            		applicantTId.setIsPH("Yes");
		            	}else {
		            		applicantTId.setIsPH("No");
		            	}
		            	
		            	
		            	String exSer = rId.getString(34);
		            	if(exSer.equalsIgnoreCase("1")) {
		            		applicantTId.setExServ("Yes");
		            	}else {
		            		applicantTId.setExServ("No");
		            	}
		            	
		            	String dExSer = rId.getString(35);
		            	if(dExSer.equalsIgnoreCase("1")) {
		            		applicantTId.setdExServ("Yes");
		            	}else {
		            		applicantTId.setdExServ("No");
		            	}
		            	
		            	
		            	applicantTId.setAadhar(rId.getString(40));
		            	
		            	String noGovtJob1 = rId.getString(44);
		            	if(noGovtJob1.equalsIgnoreCase("1")) {
		            		applicantTId.setNoGovtJob1("Yes");
		            	}else {
		            		applicantTId.setNoGovtJob1("No");
		            	}
		            	
		            	String noGovtJob2 = rId.getString(45);
		            	if(noGovtJob2.equalsIgnoreCase("1")) {
		            		applicantTId.setNoGovtJob2("Yes");
		            	}else {
		            		applicantTId.setNoGovtJob2("No");
		            	}
		            	
		            	String fatherless1 = rId.getString(46);
		            	if(fatherless1.equalsIgnoreCase("1")) {
		            		applicantTId.setFatherless1("Yes");
		            	}else {
		            		applicantTId.setFatherless1("No");
		            	}
		            	
		            	String fatherless2 = rId.getString(47);
		            	if(fatherless2.equalsIgnoreCase("1")) {
		            		applicantTId.setFatherless2("Yes");
		            	}else {
		            		applicantTId.setFatherless2("No");
		            	}
		            	
		            	String fatherless3 = rId.getString(48);
		            	if(fatherless3.equalsIgnoreCase("1")) {
		            		applicantTId.setFatherless3("Yes");
		            	}else {
		            		applicantTId.setFatherless3("No");
		            	}
		            	
		            	
		            	
		            	String steno = rId.getString(53);
		            	if(steno.equalsIgnoreCase("1")) {
		            		applicantTId.setSteno("Yes");
		            		applicantTId.setStenoLang(rId.getString(54));
		            	}else {
		            		applicantTId.setSteno("No");
		            	}
		            	
		            	applicantTId.setDateTime(rId.getString(58));
		            	 
	            	 
	            	 String status = rId.getString(56);
	            	  status = status.substring(0,1).toUpperCase()+status.substring(1).toLowerCase();
	            	  applicantTId.setApplicationStatus(status);
	            	  
	            	  System.out.println(applicantTId+"::Data");
	            	 appTid.add(applicantTId);	
	            	 
	         } 
	         request.setAttribute("applicantsDetails", appTid);
	             
	             
	         	//Educational Details
	         	 edet = conn.createStatement();
	             String getEd =  "SELECT * FROM education_details WHERE transactionid='"+id+"';";
	              
	             ResultSet rED = edet.executeQuery(getEd);
	             List<EducationalDetails> li = new ArrayList<>();
	             while(rED!=null && rED.next()) {
	            	 EducationalDetails ed= new EducationalDetails();
	            	 ed.setTid(rED.getString(2));
	            	 ed.setExamPassed(rED.getString(4));
	            	 ed.setUniversity(rED.getString(5));
	            	 ed.setCertificateNo(rED.getString(6));
	            	 ed.setDateIssue(rED.getString(7));
	            	 ed.setRollNo(rED.getString(8));
	            	 ed.setSubject(rED.getString(9));
	            	 ed.setPercentage(rED.getString(10));
	            	 ed.setYear(rED.getString(11));
	            	 ed.setDuration(rED.getString(12));
	            	 ed.setObtainedMarks(rED.getString(13));
	            	 ed.setTotalMarks(rED.getString(14));	            	 
	            	 li.add(ed);	            	 
	             }
	              
	             request.setAttribute("EducationDetails", li);
	             
	             
	             
	             //SocioEconomic Details
	             sEc = conn.createStatement();
	             String sEcdet =  "SELECT * FROM socio_service_details WHERE transactionid='"+id+"';";
	             ResultSet rSEC = sEc.executeQuery(sEcdet); 
	             List<SocioEconomic> liSE = new ArrayList<>();
	             while(rSEC!=null && rSEC.next()) { 
	            	 SocioEconomic se = new SocioEconomic();
	            	 se.setTid(rSEC.getString(2));	  
	            	 String jobNat = rSEC.getString(9);
	            	 jobNat = jobNat.substring(0,1).toUpperCase() + jobNat.substring(1).toLowerCase();
	            	  
	            	 se.setJobNature(jobNat);
	            	 se.setFromDate(rSEC.getString(5));
	            	 se.setToDate(rSEC.getString(6));
	            	 se.setExperienceYears(rSEC.getString(12));
	            	 se.setExperienceMonths(rSEC.getString(13));
	            	 se.setExperienceDays(rSEC.getString(14)); 
	            	 liSE.add(se); 
	             }
	             
	             request.setAttribute("SocioEconomic", liSE);
	             
	             
	           //Experience Details
	             sExpc = conn.createStatement();
	             String sExpdet =  "SELECT * FROM service_details WHERE transactionid='"+id+"';";
	             ResultSet rSExp = sEc.executeQuery(sExpdet); 
	             List<ExperienceDetails> liExp = new ArrayList<>();
	             if(rSExp!=null) { 
	            	 while(rSExp.next()) {
	            		 ExperienceDetails seEx = new ExperienceDetails();
		            	 seEx.setTid(rSExp.getString(2));
		            	 
		            	 seEx.setFromDate(rSExp.getString(5));
		            	 seEx.setToDate(rSExp.getString(6));
		            	 
		            	 String jobNat = rSExp.getString(9);
		            	 jobNat = jobNat.substring(0,1).toUpperCase() + jobNat.substring(1).toLowerCase();
		            	 seEx.setJobNature(jobNat);
		            	 
		            	 String natOfExp = rSExp.getString(10);
		            	 natOfExp = natOfExp.substring(0,1).toUpperCase() + natOfExp.substring(1).toLowerCase();
		            	 seEx.setNatureOfExperience(natOfExp);
		            	 
		            	 
		            	 
		            	 seEx.setExperienceYears(rSExp.getString(12));
		            	 seEx.setExperienceMonths(rSExp.getString(13));
		            	 seEx.setExperienceDays(rSExp.getString(14)); 
		            	 liExp.add(seEx); 
	            	 }
	            	 
	             }
	             
	             request.setAttribute("ExperienceDetails", liExp);
	             
	             
	             
	             
	             
	             
	           //Applied Post(s)
	             sAp = conn.createStatement();
	             String sApst =  "SELECT * FROM candidate_selected_posts JOIN posts_details ON candidate_selected_posts.cat_no=posts_details.catNo WHERE candidate_selected_posts.transactionid='"+id+"';";
	             ResultSet rAp = sAp.executeQuery(sApst); 
	             List<AppliedPosts> liAp = new ArrayList<>();
	             List<AppliedPosts> liAddp = new ArrayList<>();
	             if(rAp!=null) { 
	            	 while(rAp.next()) {
	            		 AppliedPosts seAp = new AppliedPosts();
	            		 seAp.setTid(rAp.getString(2));
	            		 
	            		 seAp.setCategoryNo(rAp.getString(3));
	            		 String adpst = rAp.getString(8);
	            		 
	            		 
	            		 seAp.setGroupNo(rAp.getString(13));
		            	 
	            		 String deptName = rAp.getString(15);
	            		 deptName = deptName.substring(0,1).toUpperCase() + deptName.substring(1).toLowerCase();
		            	 seAp.setNameOfTheDepartment(deptName);
		            	 
		            	 
		            	 String postName = rAp.getString(16);
		            	 postName = postName.substring(0,1).toUpperCase() + postName.substring(1).toLowerCase();
		            	 seAp.setNameOfThePost(postName);
		            	 
		            	 
		            	 System.out.println();
		            	 if(adpst.equalsIgnoreCase("1")) {		            		 
		            		 liAddp.add(seAp);		            		 
		            	 }else {
		            		 liAp.add(seAp); 
		            	 }
	            		  
		            	  
		            	 
	            	 }
	            	 
	             }
	             
	             request.setAttribute("AppliedPosts", liAp);
	             request.setAttribute("AddAppliedPosts", liAddp);
	             
	             
	             
	             
	             
	             
	             
	             
	             
	             
	             
	             
	             request.getRequestDispatcher("details.jsp").forward(request, response);
          
	         
	        } catch (SQLException e) {
				e.printStackTrace();
			} finally {
	             
				if (st != null) {
	                try {
	                	st.close();
	                } catch (SQLException e) {
	                    e.printStackTrace();
	                }
	            }
	            if (conn != null) {
	                try {
	                    conn.close();
	                } catch (SQLException e) {
	                    e.printStackTrace();
	                }
	            }
	        }
			
		}
		

	}