package com.ttipl.bean;


public class SocioEconomic {
    private String tid;
    private String jobNature;
    private String organizationName;
    private String designation;
    private String fromDate;
    private String toDate;
    private String issuingAuthorityDesignation;
    private String experienceYears;
    private String experienceMonths;
    private String experienceDays;
    
    
	public String getTid() {
		return tid;
	}
	public void setTid(String tid) {
		this.tid = tid;
	}
	public String getJobNature() {
		return jobNature;
	}
	public void setJobNature(String jobNature) {
		this.jobNature = jobNature;
	}
	public String getOrganizationName() {
		return organizationName;
	}
	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getIssuingAuthorityDesignation() {
		return issuingAuthorityDesignation;
	}
	public void setIssuingAuthorityDesignation(String issuingAuthorityDesignation) {
		this.issuingAuthorityDesignation = issuingAuthorityDesignation;
	}
	public String getExperienceYears() {
		return experienceYears;
	}
	public String getExperienceMonths() {
		return experienceMonths;
	}
	public String getExperienceDays() {
		return experienceDays;
	}
	public void setExperienceYears(String experienceYears) {
		this.experienceYears = experienceYears;
	}
	public void setExperienceMonths(String experienceMonths) {
		this.experienceMonths = experienceMonths;
	}
	public void setExperienceDays(String experienceDays) {
		this.experienceDays = experienceDays;
	} 
	 
}
