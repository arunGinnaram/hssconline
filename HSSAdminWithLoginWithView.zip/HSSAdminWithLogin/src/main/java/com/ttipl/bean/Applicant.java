package com.ttipl.bean;


public class Applicant {
    private String tid;
    private String fullName;
    private String firstName;
    private String lastName;
    private String middleName;
    private String fatherName;
    private String email;
    private String gender;
    private String dob;
    private String aadhar;
    private String applicationStatus;
    private String category;
    private String mobile;
    private String dateTime;
    private String motherName;
    private String maritalStatus;
    private String steno;
    private String stenoLang;
    private String isPH;
    private String exServ;
    private String dExServ;
    private String desm;
    private String isDdesm;
    private String noGovtJob1;
    private String noGovtJob2;
    private String fatherless1;
    private String fatherless2;
    private String fatherless3;
    
    public void setCategory(String category) {
    	this.category = category;
    }
    
    public String getCategory() {
    	return category;
    }
    
    
    
    
    
    
    public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getTid() {
		return tid;
	}
	public void setTid(String tid) {
		this.tid = tid;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getFatherName() {
		return fatherName;
	}
	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getAadhar() {
		return aadhar;
	}
	public void setAadhar(String aadhar) {
		this.aadhar = aadhar;
	}
	public String getApplicationStatus() {
		return applicationStatus;
	}
	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public String getSteno() {
		return steno;
	}

	public void setSteno(String steno) {
		this.steno = steno;
	}

	public String getStenoLang() {
		return stenoLang;
	}

	public void setStenoLang(String stenoLang) {
		this.stenoLang = stenoLang;
	}

	public String getIsPH() {
		return isPH;
	}

	public void setIsPH(String isPH) {
		this.isPH = isPH;
	}

	public String getExServ() {
		return exServ;
	}

	public void setExServ(String exServ) {
		this.exServ = exServ;
	}

	public String getdExServ() {
		return dExServ;
	}

	public void setdExServ(String dExServ) {
		this.dExServ = dExServ;
	}

	public String getDesm() {
		return desm;
	}

	public String getIsDdesm() {
		return isDdesm;
	}

	public void setDesm(String desm) {
		this.desm = desm;
	}

	public void setIsDdesm(String isDdesm) {
		this.isDdesm = isDdesm;
	}

	public String getNoGovtJob1() {
		return noGovtJob1;
	}

	public String getNoGovtJob2() {
		return noGovtJob2;
	}

	public void setNoGovtJob1(String noGovtJob1) {
		this.noGovtJob1 = noGovtJob1;
	}

	public void setNoGovtJob2(String noGovtJob2) {
		this.noGovtJob2 = noGovtJob2;
	}

	public String getFatherless1() {
		return fatherless1;
	}

	public String getFatherless2() {
		return fatherless2;
	}

	public String getFatherless3() {
		return fatherless3;
	}

	public void setFatherless1(String fatherless1) {
		this.fatherless1 = fatherless1;
	}

	public void setFatherless2(String fatherless2) {
		this.fatherless2 = fatherless2;
	}

	public void setFatherless3(String fatherless3) {
		this.fatherless3 = fatherless3;
	}
	
}
