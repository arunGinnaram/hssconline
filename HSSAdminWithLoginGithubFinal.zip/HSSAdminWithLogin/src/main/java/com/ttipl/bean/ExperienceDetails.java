package com.ttipl.bean;


public class ExperienceDetails {
	
    private String tid;
    private String jobNature;
    private String organizationName;
    private String designation;
    private String natureOfExperience;    
    private String fromDate;
    private String toDate;
    private String issuingAuthorityDesignation;
    private String experienceYears;
    private String experienceMonths;
    private String experienceDays;
    
    
	public String getTid() {
		return tid;
	}
	public String getJobNature() {
		return jobNature;
	}
	public String getOrganizationName() {
		return organizationName;
	}
	public String getDesignation() {
		return designation;
	}
	public String getNatureOfExperience() {
		return natureOfExperience;
	}
	public String getFromDate() {
		return fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public String getIssuingAuthorityDesignation() {
		return issuingAuthorityDesignation;
	}
	public String getExperienceYears() {
		return experienceYears;
	}
	public String getExperienceMonths() {
		return experienceMonths;
	}
	public String getExperienceDays() {
		return experienceDays;
	}
	public void setTid(String tid) {
		this.tid = tid;
	}
	public void setJobNature(String jobNature) {
		this.jobNature = jobNature;
	}
	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public void setNatureOfExperience(String natureOfExperience) {
		this.natureOfExperience = natureOfExperience;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public void setIssuingAuthorityDesignation(String issuingAuthorityDesignation) {
		this.issuingAuthorityDesignation = issuingAuthorityDesignation;
	}
	public void setExperienceYears(String experienceYears) {
		this.experienceYears = experienceYears;
	}
	public void setExperienceMonths(String experienceMonths) {
		this.experienceMonths = experienceMonths;
	}
	public void setExperienceDays(String experienceDays) {
		this.experienceDays = experienceDays;
	}
	 
}
