package com.ttipl.bean;


public class AppliedPosts {
	
    private String tid;
    private String nameOfTheDepartment;
    private String nameOfThePost;
    private String categoryNo;
    private String groupNo;
    
    
	public String getTid() {
		return tid;
	}
	public String getNameOfTheDepartment() {
		return nameOfTheDepartment;
	}
	public String getNameOfThePost() {
		return nameOfThePost;
	}
	public String getCategoryNo() {
		return categoryNo;
	}
	public String getGroupNo() {
		return groupNo;
	}
	public void setTid(String tid) {
		this.tid = tid;
	}
	public void setNameOfTheDepartment(String nameOfTheDepartment) {
		this.nameOfTheDepartment = nameOfTheDepartment;
	}
	public void setNameOfThePost(String nameOfThePost) {
		this.nameOfThePost = nameOfThePost;
	}
	public void setCategoryNo(String categoryNo) {
		this.categoryNo = categoryNo;
	}
	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}    
     
     
}
