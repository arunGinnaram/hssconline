package com.ttil.dao;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import XMLTransform.XMLTransformer;


public class AttendanceGenerationConstable {
	DBConnection dbc=null;
	Connection conn=null;



	public String bihar_we_attendanceConstable(String Photopath, String signEng, String Signhindi, String imagesPath, String xslPath, String reportsPath, int weexamcode1, 
            int wecentrecode1, int wesheetno1, String werollno, String dbhost, String dbusername, String dbpassword, String dbname){
		  String outPut = "";
	        String reportFormat = "pdf";
	        ResultSet rs = null;
	        ResultSet rs2 = null;
	        ResultSet rs1 = null;
	        PreparedStatement pstmt = null;
	        PreparedStatement pstmt1 = null;
	        PreparedStatement pstmt2 = null;
	        String Rollno = "";
	        String Name = "";
	        String fname = "";
	        String identity_type = "";
	        String aadhar_no = "";
	        String identification_mark = "";
	        String wecenter = "";
	        int wecentercode = 0;
	        int weexamcode = 0;
	        String reportName = "";
	        String c = "";
	        String appno = "";
	        StringBuffer xml = null;
	        String candidatePhoto = "";
	        String candidateSignEng = "";
	        String candidateSignHnd = "";
	        File photoFile = null;
	        File sigFile = null;
	        File hindiSigFile = null;
	        String weexamname = "";
	        String advt_no = null;
	        String tablename = "applicants_totaldata";
		
		
		try{
			String s3bucket = "";
            if(werollno != null && werollno.length() >= 5)
            {
                weexamcode1 = Integer.parseInt(werollno.substring(0, 2));
            }
            if(weexamcode1 == 15)
            {
                conn = DBConnection.getMySQLDatabaseConnection("csbc_forester_04_2020");
                s3bucket = "csbc_forester_04_2020";
            } else
            if(weexamcode1 == 12)
            {
                conn = DBConnection.getMySQLDatabaseConnection("csbc_ct_hg_2020");
                s3bucket = "csbc_ct_hg_2020";
            } else
            if(weexamcode1 == 77)
            {
                conn = DBConnection.getMySQLDatabaseConnection("csbc_ct_drivers_2019");
                s3bucket = "csbc_ct_driver_2019";
            } else
            if(weexamcode1 == 14 || weexamcode1 == 24)
            {
                conn = DBConnection.getMySQLDatabaseConnection("csbc_forest_guards_03_2020");
                s3bucket = "csbc_forest_guard_03_2020";
            } else
            if(weexamcode1 == 25 || weexamcode1 == 35 || weexamcode1 == 31 || weexamcode1 == 41)
            {
                advt_no = "05_20";
                tablename = "applicationform_details";
                conn = DBConnection.getMySQLDatabaseConnection("csbc_ct_05_2020");
                s3bucket = "csbc_const_05_2020";
            } else
            if(weexamcode1 == 18)
            {
                advt_no = "02_2021";
                tablename = "applicants";
                conn = DBConnection.getMySQLDatabaseConnection("csbc_ct_02_2021");
                s3bucket = "csbc_pct_02_2021";
            } else
            if(weexamcode1 == 16 || weexamcode1 == 26)
            {
                advt_no = "01_2021";
                tablename = "applicants";
                conn = DBConnection.getMySQLDatabaseConnectionPoperty(dbhost, dbusername, dbpassword, dbname);
                s3bucket = "csbc_fm_01_2021";
            }else if(weexamcode1 == 17) {
                    advt_no = "01_2022";
                    tablename = "applicants_totaldata";
                    conn = DBConnection.getMySQLDatabaseConnection("csbc_ct_01_2022");
                    s3bucket = "csbc_pct_02_2021";
             } 
            else if(weexamcode1 == 75)
            {
                advt_no = "02_2022";
                tablename = "applicants";
                conn = DBConnection.getMySQLDatabaseConnection("csbc_ct_02_2022");
                s3bucket = "csbc_pct_02_2021";
            }
            String updateQuery = "update attendancesheets set status=1 where weexamcode=? and wecentrecode=?";
            pstmt1 = conn.prepareStatement(updateQuery);
            String query = "";
            String query1 = "";

			if(werollno!=null && werollno.length()>=5){
				query1="select weexamcode,wecentrecode,wesheetno from "+tablename+" where werollno='"+werollno+"'";
				//System.out.println(query1);
				pstmt1=conn.prepareStatement(query1);
				rs1=pstmt1.executeQuery();
				if(rs1.next()){
					weexamcode1=rs1.getInt("weexamcode");
					wecentrecode1=rs1.getInt("wecentrecode");
					wesheetno1=rs1.getInt("wesheetno");
				}
			}
			System.out.println("weexamcode1="+weexamcode1);
			System.out.println("wecentrecode1="+wecentrecode1);
			System.out.println("wesheetno1="+wesheetno1);
			int wesheetno=wesheetno1;
			int max_sheetno=0;

			String query2="";
			if(wecentrecode1>0)
				query2="select  weexamcode,wedistrictcode,district,wecentrecode,wecentre,no_of_pages as max_sheetno,no_of_candidates,status from attendancesheets  where weexamcode ="+weexamcode1+" and wecentrecode="+wecentrecode1+"    order by wecentrecode,weexamcode";
			else
				query2="select  weexamcode,wedistrictcode,district,wecentrecode,wecentre,no_of_pages as max_sheetno,no_of_candidates,status from attendancesheets  where weexamcode ="+weexamcode1+" and status is null   order by wecentrecode,weexamcode";


			System.out.println("query2="+query2);
			pstmt2=conn.prepareStatement(query2);
			rs2=pstmt2.executeQuery();
			if(wesheetno1>0){
				query="select transactionid,werollno,concat(first_name,' ',middle_name,' ',last_name) as name,father_name,aadhar_no,identification_mark,wecentrecode from "+tablename+" where weexamcode=? and wecentrecode=? and wesheetno ="+wesheetno1+"  order by werollno ";
			}else{
				wesheetno=1;
				query="select transactionid,werollno,concat(first_name,' ',middle_name,' ',last_name) as name,father_name,aadhar_no,identification_mark,wecentrecode from "+tablename+" where weexamcode=? and wecentrecode=?    order by werollno limit 0,6  ";

			}
			System.out.println("query="+query);
			pstmt=conn.prepareStatement(query);
			while(rs2.next()){
				weexamname="";
				weexamcode=rs2.getInt("weexamcode");
				wecentercode=rs2.getInt("wecentrecode");
				wecenter=rs2.getString("wecentre");
				max_sheetno=rs2.getInt("max_sheetno");
				wecenter=wecenter.replaceAll("&", "&amp;");
				pstmt=conn.prepareStatement(query);
				pstmt.setInt(1, weexamcode);
				pstmt.setInt(2, wecentercode);
				rs=pstmt.executeQuery();
				System.out.println("wecentercode="+weexamcode+"_"+wecentercode);
				xml=new StringBuffer();

				int count=0;
				while(rs.next()){
					count++;

					//if(count<=12)
					{
						candidatePhoto="";
						candidateSignEng="";
						candidateSignHnd="";
						photoFile=null;sigFile=null;hindiSigFile=null;

						appno=rs.getString("transactionid");
						Rollno=rs.getString("werollno");
						Name=rs.getString("name").toUpperCase();
						fname=rs.getString("father_name").toUpperCase();
						//identity_type=rs.getString("identity_type").toUpperCase();
						aadhar_no=rs.getString("aadhar_no").toUpperCase();
						identification_mark=rs.getString("identification_mark").toUpperCase();
						System.out.println(count+".Rollno="+Rollno);

						candidatePhoto=Photopath+File.separator+appno+"_photo.jpg";
						candidateSignEng=signEng+File.separator+appno+"_sig.jpg";
						candidateSignHnd=Signhindi+File.separator+appno+"_sig1.jpg";
						//System.out.println("http://onlinedatafiles.s3.amazonaws.com/csbc_const_2019/photos/"+appno+"_photo.jpg");
						//
						photoFile=new File(candidatePhoto);
						if(!photoFile.exists()){
							//System.out.println(photoFile.getAbsolutePath());
							try{
								//URL url = new URL("http://onlinedatafiles.s3.amazonaws.com/csbc_forest_guard_03_2020/photos/"+appno+"_photo.jpg");
								URL url = new URL("http://3.108.242.32:86/ProhCT0222/candidateImages/" + appno + "_photo.jpg");
								InputStream is = url.openStream();
								OutputStream os = new FileOutputStream(candidatePhoto);
								byte[] b = new byte[2048];
								int length;

								while ((length = is.read(b)) != -1) {
									os.write(b, 0, length);
								}
								is.close();
								os.close();
							}catch(Exception e){
								e.printStackTrace();
							}
						}
						sigFile=new File(candidateSignEng);
						if(!sigFile.exists()){
							//System.out.println(sigFile.getAbsolutePath());
							try{
								//URL url = new URL("http://onlinedatafiles.s3.amazonaws.com/csbc_forest_guard_03_2020/signatures/"+appno+"_sig.jpg");
							//	URL url = new URL("http://onlinedatafiles.s3.amazonaws.com/"+s3bucket+"/signatures/"+appno+"_sig.jpg");
								URL url = new URL("http://3.108.242.32:86/ProhCT0222/candidateImages/" + appno + "_sig.jpg");
								InputStream is = url.openStream();
								OutputStream os = new FileOutputStream(candidateSignEng);
								byte[] b = new byte[2048];
								int length;

								while ((length = is.read(b)) != -1) {
									os.write(b, 0, length);
								}
								is.close();
								os.close();
							}catch(Exception e){
								e.printStackTrace();
							}
						}

						hindiSigFile=new File(candidateSignHnd);
						if(!hindiSigFile.exists()){
							//System.out.println(hindiSigFile.getAbsolutePath());
							try{
								//URL url = new URL("http://onlinedatafiles.s3.amazonaws.com/csbc_forest_guard_03_2020/signatureshindi/"+appno+"_sig1.jpg");
								//URL url = new URL("http://onlinedatafiles.s3.amazonaws.com/"+s3bucket+"/signatureshindi/"+appno+"_sig1.jpg");
								URL url = new URL("http://3.108.242.32:86/ProhCT0222/candidateImages/" + appno + "_sig1.jpg");
								InputStream is = url.openStream();
								OutputStream os = new FileOutputStream(candidateSignHnd);
								byte[] b = new byte[2048];
								int length;
								while ((length = is.read(b)) != -1) {
									os.write(b, 0, length);
								}
								is.close();
								os.close();
							}catch(Exception e){
								e.printStackTrace();
							}
						}

						//DetermineFormatOfAnImage.getImageType(candidatePhoto, appno);
						//System.out.println(candidateSignEng);
						//System.out.println(candidateSignHnd);
						
						   DetermineFormatOfAnImage.getImageType(candidatePhoto, appno, "photo");
		                    DetermineFormatOfAnImage.getImageType(candidateSignEng, appno, "sig");
		                    DetermineFormatOfAnImage.getImageType(candidateSignHnd, appno, "sig1");
		                    
						xml.append("<row>");
						xml.append("<rollno>"+Rollno+"</rollno>");
						xml.append("<name>"+Name+"</name>");
						xml.append("<fname>"+fname+"</fname>");
						xml.append("<idno>"+aadhar_no+"</idno>");
						xml.append("<idmark>"+identification_mark+"</idmark>");
						xml.append("<canphoto>"+candidatePhoto+"</canphoto>");
						xml.append("<canesign>"+candidateSignEng+"</canesign>");
						xml.append("<canhsign>"+candidateSignHnd+"</canhsign>");
						xml.append("</row>");
					}

				}
				 if(weexamcode == 12)
	                {
	                    weexamname = "HS/2/20/12";
	                }
	                if(weexamcode == 22)
	                {
	                    weexamname = "PK/2/19/22";
	                } else
	                if(weexamcode == 33)
	                {
	                    weexamname = "PK/2/19/33";
	                } else
	                if(weexamcode == 44)
	                {
	                    weexamname = "PK/2/19/44";
	                } else
	                if(weexamcode == 55)
	                {
	                    weexamname = "PK/2/19/55";
	                } else
	                if(weexamcode == 66)
	                {
	                    weexamname = "TM/4/19/66";
	                } else
	                if(weexamcode == 77)
	                {
	                    weexamname = "PD/5/19/77";
	                } else
	                if(weexamcode == 11)
	                {
	                    weexamname = "SP/1/20/11";
	                } else
	                if(weexamcode == 14)
	                {
	                    weexamname = "FG/3/20/14";
	                } else
	                if(weexamcode == 24)
	                {
	                    weexamname = "FG/3/20/24";
	                } else
	                if(weexamcode == 15)
	                {
	                    weexamname = "FR/4/20/15";
	                } else
	                if(weexamcode == 25)
	                {
	                    weexamname = "CP/5/20/25";
	                } else
	                if(weexamcode == 35)
	                {
	                    weexamname = "CP/5/20/35";
	                } else
	                if(weexamcode == 31)
	                {
	                    weexamname = "CP/5/20/31";
	                } else
	                if(weexamcode == 41)
	                {
	                    weexamname = "CP/5/20/41";
	                } else
	                if(weexamcode == 18)
	                {
	                    weexamname = "SM/DO/21/18";
	                } else
	                if(weexamcode == 16)
	                {
	                    weexamname = "MF/1/21/16";
	                } else    if(weexamcode == 26)
	                {
	                    weexamname = "MF/1/21/26";
	                }else if(weexamcode == 17)
		                {
		                    weexamname = "MN/1/22/17";
		                }
	                else if(weexamcode == 75)
	                {
	                    weexamname = "PC/2/22/75";
	                }
				
				

				reportName=weexamcode+"_"+wecentercode+"_Sheet-"+wesheetno+"_Attendace_Sheet";
				c="<root><examcode>"+weexamcode+"</examcode><weexamname>"+weexamname+"</weexamname><center_code>"+wecentercode+"</center_code><center_name>"+wecenter+"</center_name><pageno>"+wesheetno+"</pageno><maxpageno>"+max_sheetno+"</maxpageno>";
				xml.append("</root>");
				String x=c+xml;
				try{
					StringReader rd=new StringReader(x);
					if(reportFormat.length()>=0){
						outPut=new XMLTransformer().GetTransformedString(rd, "pdf", "ConstableAttendanceSheet_GivenformatLegal",reportName,xslPath,reportsPath);
						pstmt1.setInt(1, weexamcode);
						pstmt1.setInt(2, wecentercode);
						pstmt1.executeUpdate();
					}
				}catch(Exception e){
					e.printStackTrace();
				}
			}

		}catch(Exception e){
			e.printStackTrace();
		}
		return outPut;	
	}



	public String bihar_we_attendanceConstableByRollnos(String Photopath,String signEng,String Signhindi,String imagesPath,String xslPath,String reportsPath,int weexamcode1,int wecentrecode1,int wesheetno1,String werollno){
		String outPut="",reportFormat="pdf";
		ResultSet rs=null;
		ResultSet rs2=null,rs1=null;
		PreparedStatement pstmt=null,pstmt1=null;
		PreparedStatement pstmt2=null;
		String Rollno="",Name="",fname="",identity_type="",aadhar_no="",identification_mark="",wecenter="";
		int wecentercode=0,weexamcode=0;
		String reportName="";
		String c="";
		String appno="";
		StringBuffer xml =null;
		String candidatePhoto="";
		String candidateSignEng="";
		String candidateSignHnd="";
		File photoFile=null,sigFile=null,hindiSigFile=null;
		String weexamname="";
		try{
			conn=DBConnection.getMySQLDatabaseConnection();
			 String advt_no = "01_2022";
			 String  tablename = "applicants_totaldata";
             conn = DBConnection.getMySQLDatabaseConnection("csbc_01_2022");
             String  s3bucket = "csbc_pct_02_2021";
             
			String updateQuery="update attendancesheets set status=1 where weexamcode=? and wecentrecode=?";
		//	pstmt1=conn.prepareStatement(updateQuery);

			String query="",query1="";
			//query1="select weexamcode,wecentrecode,wesheetno from applicants where werollno in ('1511090245','1511110274','1511110098','1511120097','1511160277','1511200268','1511300008','1514030106','1514050400','1514050268','1514050045','1514060526','1514060087','1514070530','1514070257','1514100231','1514170157','1519060078','1520010891','1520020962','1520020261','1520020083','1520030778','1520030284','1520040001','1523020120','1523020165','1523020207','1523030199','1523040033','1524020147','1524030324','1524040492','1524040524','1526030238','1526040018','1526050221','1526070225','1526070077','1526100405','1526100147','1526100055','1526100056','1531040008','1535030381','1535040186','1531080066','1540040077','1540050193','1532050217','1541050012','1542020232','1542030333','1545050209','1546030735','1527100004','1527100075','1527110316','1528010755','1528010199','1528010022','1528020965','1528021157','1527011166','1527020699','1527020138','1527020219','1527030204','1527070400','1529020341','1529020458','1533010532','1533010335','1533020200','1533030105','1534030163','1534060069','1538020058','1538020091','1539010370','1539010480','1539010684','1543090010','1543090164','1543170161','1510040591','1511060462','1510090004','1510100594','1510150372','1510160106','1510160036','1510220158','1510220185','1513010803','1513010243','1513020998','1513020996','1515010026','1515030217','1515060166','1515120095','1512010463','1512010435','1512020283','1512030011','1512040079','1512100047','1516030694','1516060315','1516070641','1516080400','1516140213','1516140119','1516190121','1521030396','1521030195','1521040161','1521080046','1521090096','1521100055','1517070019','1517100376','1517120232','1518010721','1518030239','1518080108','1518050319','1518050296','1518100035') order by werollno";
			query1="select weexamcode,wecentrecode,wesheetno from "+tablename+" where werollno in ('1710011294') order by werollno"; 
			//System.out.println(query1);
			pstmt1=conn.prepareStatement(query1);
			rs1=pstmt1.executeQuery();
			while(rs1.next()){
				weexamcode1=rs1.getInt("weexamcode");
				wecentrecode1=rs1.getInt("wecentrecode");
				wesheetno1=rs1.getInt("wesheetno");

				System.out.println("weexamcode1="+weexamcode1);
				System.out.println("wecentrecode1="+wecentrecode1);
				System.out.println("wesheetno1="+wesheetno1);
				int wesheetno=wesheetno1;
				int max_sheetno=0;

				String query2="";
				if(wecentrecode1>0)
					query2="select  weexamcode,wedistrictcode,district,wecentrecode,wecentre,no_of_pages as max_sheetno,no_of_candidates,status from attendancesheets  where weexamcode ="+weexamcode1+" and wecentrecode="+wecentrecode1+"    order by wecentrecode,weexamcode";
				else
					query2="select  weexamcode,wedistrictcode,district,wecentrecode,wecentre,no_of_pages as max_sheetno,no_of_candidates,status from attendancesheets  where weexamcode ="+weexamcode1+" and status is null   order by wecentrecode,weexamcode";


				System.out.println("query2="+query2);
				pstmt2=conn.prepareStatement(query2);
				rs2=pstmt2.executeQuery();
				if(wesheetno1>0){
					query="select transactionid,werollno,concat(first_name,' ',middle_name,' ',last_name) as name,father_name,aadhar_no,identification_mark,wecentrecode from "+tablename+" where weexamcode=? and wecentrecode=? and wesheetno ="+wesheetno1+"  order by werollno ";
				}else{
					wesheetno=1;
					query="select transactionid,werollno,concat(first_name,' ',middle_name,' ',last_name) as name,father_name,aadhar_no,identification_mark,wecentrecode from "+tablename+" where weexamcode=? and wecentrecode=?    order by werollno  ";

				}
				System.out.println("query="+query);
				pstmt=conn.prepareStatement(query);
				while(rs2.next()){
					weexamname="";
					weexamcode=rs2.getInt("weexamcode");
					wecentercode=rs2.getInt("wecentrecode");
					wecenter=rs2.getString("wecentre");
					max_sheetno=rs2.getInt("max_sheetno");
					wecenter=wecenter.replaceAll("&", "&amp;");
					pstmt=conn.prepareStatement(query);
					pstmt.setInt(1, weexamcode);
					pstmt.setInt(2, wecentercode);
					rs=pstmt.executeQuery();
					System.out.println("wecentercode="+weexamcode+"_"+wecentercode);
					xml=new StringBuffer();

					int count=0;
					while(rs.next()){
						count++;

						//if(count<=12)
						{
							candidatePhoto="";
							candidateSignEng="";
							candidateSignHnd="";
							photoFile=null;sigFile=null;hindiSigFile=null;

							appno=rs.getString("transactionid");
							Rollno=rs.getString("werollno");
							Name=rs.getString("name").toUpperCase();
							fname=rs.getString("father_name").toUpperCase();
							//identity_type=rs.getString("identity_type").toUpperCase();
							aadhar_no=rs.getString("aadhar_no").toUpperCase();
							identification_mark=rs.getString("identification_mark").toUpperCase();
							//System.out.println(count+".Rollno="+Rollno);

							candidatePhoto=Photopath+File.separator+appno+"_photo.jpg";
							candidateSignEng=signEng+File.separator+appno+"_sig.jpg";
							candidateSignHnd=Signhindi+File.separator+appno+"_sig1.jpg";
							//System.out.println("http://onlinedatafiles.s3.amazonaws.com/csbc_const_2019/photos/"+appno+"_photo.jpg");
							//
							
							/**
							photoFile=new File(candidatePhoto);
							if(!photoFile.exists()){
								//System.out.println(photoFile.getAbsolutePath());
								try{
									//URL url = new URL("http://onlinedatafiles.s3.amazonaws.com/csbc_forest_guard_03_2020/photos/"+appno+"_photo.jpg");
									URL url = new URL("http://3.108.242.32:86/CSBCV1/candidateImages/" + appno + "_photo.jpg");
									InputStream is = url.openStream();
									OutputStream os = new FileOutputStream(candidatePhoto);
									byte[] b = new byte[2048];
									int length;

									while ((length = is.read(b)) != -1) {
										os.write(b, 0, length);
									}
									is.close();
									os.close();
								}catch(Exception e){
									e.printStackTrace();
								}
							}
							sigFile=new File(candidateSignEng);
							if(!sigFile.exists()){
								//System.out.println(sigFile.getAbsolutePath());
								try{
									//URL url = new URL("http://onlinedatafiles.s3.amazonaws.com/csbc_forest_guard_03_2020/signatures/"+appno+"_sig.jpg");
								//	URL url = new URL("http://onlinedatafiles.s3.amazonaws.com/"+s3bucket+"/signatures/"+appno+"_sig.jpg");
									URL url = new URL("http://3.108.242.32:86/CSBCV1/candidateImages/" + appno + "_sig.jpg");
									InputStream is = url.openStream();
									OutputStream os = new FileOutputStream(candidateSignEng);
									byte[] b = new byte[2048];
									int length;

									while ((length = is.read(b)) != -1) {
										os.write(b, 0, length);
									}
									is.close();
									os.close();
								}catch(Exception e){
									e.printStackTrace();
								}
							}

							hindiSigFile=new File(candidateSignHnd);
							if(!hindiSigFile.exists()){
								//System.out.println(hindiSigFile.getAbsolutePath());
								try{
									//URL url = new URL("http://onlinedatafiles.s3.amazonaws.com/csbc_forest_guard_03_2020/signatureshindi/"+appno+"_sig1.jpg");
									//URL url = new URL("http://onlinedatafiles.s3.amazonaws.com/"+s3bucket+"/signatureshindi/"+appno+"_sig1.jpg");
									URL url = new URL("http://3.108.242.32:86/CSBCV1/candidateImages/" + appno + "_sig1.jpg");
									InputStream is = url.openStream();
									OutputStream os = new FileOutputStream(candidateSignHnd);
									byte[] b = new byte[2048];
									int length;
									while ((length = is.read(b)) != -1) {
										os.write(b, 0, length);
									}
									is.close();
									os.close();
								}catch(Exception e){
									e.printStackTrace();
								}
							}
**/
							//DetermineFormatOfAnImage.getImageType(candidatePhoto, appno);
							//System.out.println(candidateSignEng);
							//System.out.println(candidateSignHnd);
							
							   DetermineFormatOfAnImage.getImageType(candidatePhoto, appno, "photo");
			                    DetermineFormatOfAnImage.getImageType(candidateSignEng, appno, "sig");
			                    DetermineFormatOfAnImage.getImageType(candidateSignHnd, appno, "sig1");
			                    
							xml.append("<row>");
							xml.append("<rollno>"+Rollno+"</rollno>");
							xml.append("<name>"+Name+"</name>");
							xml.append("<fname>"+fname+"</fname>");
							xml.append("<idno>"+aadhar_no+"</idno>");
							xml.append("<idmark>"+identification_mark+"</idmark>");
							xml.append("<canphoto>"+candidatePhoto+"</canphoto>");
							xml.append("<canesign>"+candidateSignEng+"</canesign>");
							xml.append("<canhsign>"+candidateSignHnd+"</canhsign>");
							xml.append("</row>");
						}

					}
					 if(weexamcode == 12)
		                {
		                    weexamname = "HS/2/20/12";
		                }
		                if(weexamcode == 22)
		                {
		                    weexamname = "PK/2/19/22";
		                } else
		                if(weexamcode == 33)
		                {
		                    weexamname = "PK/2/19/33";
		                } else
		                if(weexamcode == 44)
		                {
		                    weexamname = "PK/2/19/44";
		                } else
		                if(weexamcode == 55)
		                {
		                    weexamname = "PK/2/19/55";
		                } else
		                if(weexamcode == 66)
		                {
		                    weexamname = "TM/4/19/66";
		                } else
		                if(weexamcode == 77)
		                {
		                    weexamname = "PD/5/19/77";
		                } else
		                if(weexamcode == 11)
		                {
		                    weexamname = "SP/1/20/11";
		                } else
		                if(weexamcode == 14)
		                {
		                    weexamname = "FG/3/20/14";
		                } else
		                if(weexamcode == 24)
		                {
		                    weexamname = "FG/3/20/24";
		                } else
		                if(weexamcode == 15)
		                {
		                    weexamname = "FR/4/20/15";
		                } else
		                if(weexamcode == 25)
		                {
		                    weexamname = "CP/5/20/25";
		                } else
		                if(weexamcode == 35)
		                {
		                    weexamname = "CP/5/20/35";
		                } else
		                if(weexamcode == 31)
		                {
		                    weexamname = "CP/5/20/31";
		                } else
		                if(weexamcode == 41)
		                {
		                    weexamname = "CP/5/20/41";
		                } else
		                if(weexamcode == 18)
		                {
		                    weexamname = "SM/DO/21/18";
		                } else
		                if(weexamcode == 16)
		                {
		                    weexamname = "MF/1/21/16";
		                } else
		                if(weexamcode == 26)
		                {
		                    weexamname = "MF/1/21/26";
		                }else
			                if(weexamcode == 17)
			                {
			                    weexamname = "MN/1/22/17";
			                }
					
					

					reportName=weexamcode+"_"+wecentercode+"_Sheet-"+wesheetno+"_Attendace_Sheet";
					c="<root><examcode>"+weexamcode+"</examcode><weexamname>"+weexamname+"</weexamname><center_code>"+wecentercode+"</center_code><center_name>"+wecenter+"</center_name><pageno>"+wesheetno+"</pageno><maxpageno>"+max_sheetno+"</maxpageno>";
					xml.append("</root>");
					String x=c+xml;
					try{
						StringReader rd=new StringReader(x);
						if(reportFormat.length()>=0){
							outPut=new XMLTransformer().GetTransformedString(rd, "pdf", "ConstableAttendanceSheet_GivenformatLegal",reportName,xslPath,reportsPath);
							/*
							 * pstmt1.setInt(1, weexamcode); pstmt1.setInt(2, wecentercode);
							 * pstmt1.executeUpdate();
							 */
						}
					}catch(Exception e){
						e.printStackTrace();
					}
				}
			}

		}catch(Exception e){
			e.printStackTrace();
		}
		return outPut;	
	}





}
