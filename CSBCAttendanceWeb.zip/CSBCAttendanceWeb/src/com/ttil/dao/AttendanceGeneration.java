package com.ttil.dao;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import XMLTransform.XMLTransformer;


public class AttendanceGeneration {
	DBConnection dbc=null;
	Connection conn=null;




	public String bihar_we_attendanceHDD(String Photopath,String signEng,String Signhindi,String imagesPath,String xslPath,String reportsPath,int wecentrecode,int wesheetno){
		String outPut="",reportFormat="pdf";
		ResultSet rs=null;
		ResultSet rs2=null;
		PreparedStatement pstmt=null;
		PreparedStatement pstmt2=null;
		String Rollno="",Name="",fname="",identity_type="",aadhar_no="",identification_mark="",wecenter="";
		int wecentercode=0,weexamcode=0;
		String reportName="";
		String c="";
		String appno="";
		StringBuffer xml =null;
		String candidatePhoto="";
		String candidateSignEng="";
		String candidateSignHnd="";

		String candidatePhoto1="";
		String candidateSignEng1="";
		String candidateSignHnd1="";
		File photoFile=null,sigFile=null,hindiSigFile=null;

		try{
			conn=DBConnection.getMySQLDatabaseConnection();
			//String query2="select wedistrictcode,wecentrecode,wecentre,count(*) as alloted_count from applicants  where wecentrecode="+wecentrecode+"  group by wedistrictcode,wecentrecode,wecentre";
			String query2="select  weexamcode,wedistrictcode,district,wecentrecode,wecentre,no_of_pages as max_sheetno,no_of_candidates,status from attendancesheets  where  wecentrecode="+wecentrecode+"  order by wecentrecode,weexamcode";
			pstmt2=conn.prepareStatement(query2);
			rs2=pstmt2.executeQuery();
			int max_sheetno=0;
			String query="";
			if(wesheetno>0)
				query="select transactionid,werollno,concat(first_name,' ',middle_name,' ',last_name) as name,father_name,identity_type,aadhar_no,identification_mark,wecentrecode from applicants where  wecentrecode=?  and wesheetno="+wesheetno+" order by werollno    ";
			else {
				wesheetno=1;
				query="select transactionid,werollno,concat(first_name,' ',middle_name,' ',last_name) as name,father_name,identity_type,aadhar_no,identification_mark,wecentrecode from applicants where  wecentrecode=?  order by werollno    ";
			}
			pstmt=conn.prepareStatement(query);


			while(rs2.next())
			{
				weexamcode=rs2.getInt("weexamcode");
				wecentercode=rs2.getInt("wecentrecode");
				wecenter=rs2.getString("wecentre");
				max_sheetno=rs2.getInt("max_sheetno");
				wecenter=wecenter.replaceAll("&", "&amp;");
				pstmt.setInt(1, wecentercode);

				rs=pstmt.executeQuery();

				xml=new StringBuffer();
				int count=0;
				while(rs.next()){
					count++;

					//if(count<=12)
					{
						candidatePhoto="";
						candidateSignEng="";
						candidateSignHnd="";

						candidatePhoto1="";
						candidateSignEng1="";
						candidateSignHnd1="";

						photoFile=null;sigFile=null;hindiSigFile=null;

						appno=rs.getString("transactionid");
						Rollno=rs.getString("werollno");
						Name=rs.getString("name").toUpperCase();
						fname=rs.getString("father_name").toUpperCase();
						identity_type=rs.getString("identity_type").toUpperCase();
						aadhar_no=rs.getString("aadhar_no").toUpperCase();
						identification_mark=rs.getString("identification_mark").toUpperCase();

						candidatePhoto=Photopath+File.separator+appno+"_photo.jpg";
						candidateSignEng=signEng+File.separator+appno+"_sig.jpg";
						candidateSignHnd=Signhindi+File.separator+appno+"_sig1.jpg";

						//System.out.println(candidatePhoto);
						photoFile=new File(candidatePhoto);
						try{
							if(!photoFile.exists()){
								//System.out.println("photo="+appno);
								URL url = new URL("http://onlinedatafiles.s3.amazonaws.com/bpssc_si_jail/photos/"+appno+"_photo.jpg");
								InputStream is = url.openStream();
								OutputStream os = new FileOutputStream(candidatePhoto);
								byte[] b = new byte[2048];
								int length;

								while ((length = is.read(b)) != -1) {
									os.write(b, 0, length);
								}
								is.close();
								os.close();

							}
						}catch(Exception e){

						}

						try{
							sigFile=new File(candidateSignEng);
							if(!sigFile.exists()){
								URL url = new URL("http://onlinedatafiles.s3.amazonaws.com/bpssc_si_jail/signatures/"+appno+"_sig.jpg");
								InputStream is = url.openStream();
								OutputStream os = new FileOutputStream(candidateSignEng);
								byte[] b = new byte[2048];
								int length;

								while ((length = is.read(b)) != -1) {
									os.write(b, 0, length);
								}
								is.close();
								os.close();
							}
						}catch(Exception e){

						}

						try{
							hindiSigFile=new File(candidateSignHnd);
							if(!hindiSigFile.exists()){
								URL url = new URL("http://onlinedatafiles.s3.amazonaws.com/bpssc_si_jail/signatureshindi/"+appno+"_sig1.jpg");
								InputStream is = url.openStream();
								OutputStream os = new FileOutputStream(candidateSignHnd);
								byte[] b = new byte[2048];
								int length;

								while ((length = is.read(b)) != -1) {
									os.write(b, 0, length);
								}
								is.close();
								os.close();
							}
						}catch(Exception e){

						}
						/*DetermineFormatOfAnImage.getImageType(candidatePhoto,Rollno);
						DetermineFormatOfAnImage.getImageType(candidateSignEng,Rollno);
						DetermineFormatOfAnImage.getImageType(candidateSignHnd,Rollno);*/
						//System.out.println(Rollno);
						xml.append("<row>");
						xml.append("<rollno>"+Rollno+"</rollno>");
						xml.append("<name>"+Name+"</name>");
						xml.append("<fname>"+fname+"</fname>");
						xml.append("<idno>"+identity_type+" - "+aadhar_no+"</idno>");
						xml.append("<idmark>"+identification_mark+"</idmark>");
						xml.append("<canphoto>"+candidatePhoto+"</canphoto>");
						xml.append("<canesign>"+candidateSignEng+"</canesign>");
						xml.append("<canhsign>"+candidateSignHnd+"</canhsign>");
						xml.append("</row>");
					}

				}
				String xsl_fo="";
				if(wecentercode>=5000){
					xsl_fo="qbnoAttendanceSheet_GivenformatLegal_shift2";
				}else{
					xsl_fo="qbnoAttendanceSheet_GivenformatLegal";
				}
				reportName=wecentercode+"_Sheet-"+wesheetno+"_Attendace_Sheet";
				c="<root><imagesPath>"+imagesPath+"</imagesPath><center_code>"+wecentercode+"</center_code><center_name>"+wecenter+"</center_name> <pageno>"+wesheetno+"</pageno><maxpageno>"+max_sheetno+"</maxpageno>";
				xml.append("</root>");
				String x=c+xml;
				try{
					//System.out.println("X="+x);
					StringReader rd=new StringReader(x);
					if(reportFormat.length()>=0){
						outPut=new XMLTransformer().GetTransformedString(rd, "pdf", xsl_fo,reportName,xslPath,reportsPath);
					}
				}catch(Exception e){
					e.printStackTrace();
				}
			}

		}catch(Exception e){
			e.printStackTrace();
		}
		return outPut;	
	}

	public String bihar_we_attendanceHDDAfterNoonShift(String Photopath,String signEng,String Signhindi,String Photopath1){
		String outPut="",reportFormat="pdf";
		ResultSet rs=null;
		ResultSet rs2=null;
		PreparedStatement pstmt=null;
		PreparedStatement pstmt2=null;
		String Rollno="",Name="",fname="",identity_type="",aadhar_no="",identification_mark="",wecenter="";
		int wecentercode=0;
		String reportName="";
		String c="";
		String appno="";
		StringBuffer xml =null;
		String candidatePhoto="";
		String candidateSignEng="";
		String candidateSignHnd="";

		String candidatePhoto1="";
		String candidateSignEng1="";
		String candidateSignHnd1="";
		File photoFile=null,sigFile=null,hindiSigFile=null;

		try{
			conn=DBConnection.getMySQLDatabaseConnection();
			String query2="select wedistrictcode,wecentrecode,wecentre,count(*) as alloted_count from applicants  where wecentrecode = 5003  group by wedistrictcode,wecentrecode,wecentre";
			pstmt2=conn.prepareStatement(query2);
			rs2=pstmt2.executeQuery();
			//1001
			//String query="select transactionid,werollno,concat(first_name,' ',middle_name,' ',last_name) as name,father_name,identity_type,aadhar_no,identification_mark,wecentercode2 from applicants where wecentercode2=?  and wesheetno2=1 order by werollno2";
			String query="select transactionid,werollno,concat(first_name,' ',middle_name,' ',last_name) as name,father_name,identity_type,aadhar_no,identification_mark,wecentrecode from applicants where application_status='COMPLETED' and wecentrecode=? and new_admitcard is not null  order by werollno  ";
			pstmt=conn.prepareStatement(query);


			while(rs2.next())
			{
				wecentercode=rs2.getInt("wecentrecode");
				wecenter=rs2.getString("wecentre");
				wecenter=wecenter.replaceAll("&", "&amp;");
				pstmt.setInt(1, wecentercode);
				//wecentercode=1001;
				//wecenter="D.P.C.S.S. Miller Senior Secondary School, Birchand Patel Path, Patna.";

				rs=pstmt.executeQuery();

				xml=new StringBuffer();
				//Rollno="481001"; 
				int count=0;
				while(rs.next()){
					count++;

					//if(count<=12)
					{
						candidatePhoto="";
						candidateSignEng="";
						candidateSignHnd="";

						candidatePhoto1="";
						candidateSignEng1="";
						candidateSignHnd1="";

						photoFile=null;sigFile=null;hindiSigFile=null;

						appno=rs.getString("transactionid");
						Rollno=rs.getString("werollno");
						//Rollno="481001000"+count;
						Name=rs.getString("name").toUpperCase();
						fname=rs.getString("father_name").toUpperCase();
						identity_type=rs.getString("identity_type").toUpperCase();
						aadhar_no=rs.getString("aadhar_no").toUpperCase();
						identification_mark=rs.getString("identification_mark").toUpperCase();

						candidatePhoto=Photopath+File.separator+appno+"_photo.jpg";
						candidateSignEng=signEng+File.separator+appno+"_sig.jpg";
						candidateSignHnd=Signhindi+File.separator+appno+"_sig1.jpg";
						//System.out.println(candidatePhoto);
						candidatePhoto1=Photopath1+File.separator+appno+"_photo.jpg";

						photoFile=new File(candidatePhoto);
						try{
							if(!photoFile.exists()){
								photoFile=new File(candidatePhoto1);
								if(!photoFile.exists()){
									System.out.println("photo="+appno);
									URL url = new URL("http://onlinedatafiles.s3.amazonaws.com/bpssc_si_jail/photos/"+appno+"_photo.jpg");
									InputStream is = url.openStream();
									OutputStream os = new FileOutputStream(candidatePhoto);
									byte[] b = new byte[2048];
									int length;

									while ((length = is.read(b)) != -1) {
										os.write(b, 0, length);
									}
									is.close();
									os.close();

								}else{
									candidatePhoto=candidatePhoto1;
								}
							}
						}catch(Exception e){

						}

						try{
							sigFile=new File(candidateSignEng);
							if(!sigFile.exists()){
								URL url = new URL("http://onlinedatafiles.s3.amazonaws.com/bpssc_si_jail/signatures/"+appno+"_sig.jpg");
								InputStream is = url.openStream();
								OutputStream os = new FileOutputStream(candidateSignEng);
								byte[] b = new byte[2048];
								int length;

								while ((length = is.read(b)) != -1) {
									os.write(b, 0, length);
								}
								is.close();
								os.close();
							}
						}catch(Exception e){

						}

						try{
							hindiSigFile=new File(candidateSignHnd);
							if(!hindiSigFile.exists()){
								System.out.println(candidateSignHnd);
								URL url = new URL("http://onlinedatafiles.s3.amazonaws.com/bpssc_si_jail/signatureshindi/"+appno+"_sig1.jpg");
								InputStream is = url.openStream();
								OutputStream os = new FileOutputStream(candidateSignHnd);
								byte[] b = new byte[2048];
								int length;

								while ((length = is.read(b)) != -1) {
									os.write(b, 0, length);
								}
								is.close();
								os.close();
							}
						}catch(Exception e){
							e.printStackTrace();
						}
						/*DetermineFormatOfAnImage.getImageType(candidatePhoto,Rollno);
						DetermineFormatOfAnImage.getImageType(candidateSignEng,Rollno);
						DetermineFormatOfAnImage.getImageType(candidateSignHnd,Rollno);*/
						//System.out.println(Rollno);
						xml.append("<row>");
						xml.append("<rollno>"+Rollno+"</rollno>");
						xml.append("<name>"+Name+"</name>");
						xml.append("<fname>"+fname+"</fname>");
						xml.append("<idno>"+identity_type+" - "+aadhar_no+"</idno>");
						xml.append("<idmark>"+identification_mark+"</idmark>");
						xml.append("<canphoto>"+candidatePhoto+"</canphoto>");
						xml.append("<canesign>"+candidateSignEng+"</canesign>");
						xml.append("<canhsign>"+candidateSignHnd+"</canhsign>");
						xml.append("</row>");
					}

				}

				reportName=wecentercode+"_Attendace_Sheet";
				c="<root><center_code>"+wecentercode+"</center_code><center_name>"+wecenter+"</center_name>";
				xml.append("</root>");
				String x=c+xml;
				try{
					//System.out.println("X="+x);
					StringReader rd=new StringReader(x);
					if(reportFormat.length()>=0){
						//outPut=new XMLTransformer().GetTransformedString(rd, "pdf", "qbnoAttendanceSheet_GivenformatLegal_shift2",reportName);
					}
				}catch(Exception e){
					e.printStackTrace();
				}
			}

		}catch(Exception e){
			e.printStackTrace();
		}
		return outPut;	
	}


	public static void main(String[] args){
		AttendanceGeneration  attgen=new AttendanceGeneration();
		String photopath="candidate_photos";
		String signPath="candidate_sign";
		String signPathHindi="candidate_sign_hindi";
		/*String photopath1="F:/Bpssc_si_jail_2019/detection_completed";
		String photopath2="F:/Bpssc_si_jail_2019/detection_completed";
		String signPath1="F:/Bpssc_si_jail_2019/signatures";*/
		String photopath1="D:/DOCS/BPSSC/SI_JAIL_SERGENT_2019/WRITTENEXAM/attphotos";
		String photopath2="D:/DOCS/BPSSC/SI_JAIL_SERGENT_2019/WRITTENEXAM/attphotos";
		String signPath1="D:/DOCS/BPSSC/SI_JAIL_SERGENT_2019/WRITTENEXAM/attphotos";
		String signPathHindi1="D:/DOCS/BPSSC/SI_JAIL_SERGENT_2019/WRITTENEXAM/attphotos";
		//attgen.bihar_we_attendanceHDD(photopath1, signPath1, signPathHindi1, photopath2);
		//attgen.bihar_we_attendanceHDDAfterNoonShift(photopath1, signPath1, signPathHindi1, photopath2);


		//attgen.fetchImagesFromS3Bucket("downloadedphotos", "downloadedphotos", "downloadedphotos");
		//attgen.bihar_we_attendance("downloadedphotos","downloadedphotos","downloadedphotos");


	}
}
