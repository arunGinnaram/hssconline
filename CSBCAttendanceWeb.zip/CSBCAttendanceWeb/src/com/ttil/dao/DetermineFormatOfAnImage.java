package com.ttil.dao;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

import org.apache.commons.io.FileUtils;

public class DetermineFormatOfAnImage {

	public static void main(String[] args) throws IOException {

		// get image format in a file

	}

	public static String getImageType(String image, String rollno, String type) {
		try{
			String imageType=null;
			File file = new File(image);
			ImageInputStream iis = ImageIO.createImageInputStream(file);
			Iterator<ImageReader> iter = ImageIO.getImageReaders(iis);
			if (!iter.hasNext()) {
				imageType= "null";
			}else{
				ImageReader reader = iter.next();
				iis.close();
				imageType=reader.getFormatName();
			}
			if(!"JPEG".equalsIgnoreCase(imageType) ){
				System.out.println(rollno+"-"+image+" Name="+file.getName());
				//read image file
				BufferedImage  bufferedImage = ImageIO.read(new File(image));
				// create a blank, RGB, same width and height, and a white background
				BufferedImage newBufferedImage = new BufferedImage(bufferedImage.getWidth(),
						bufferedImage.getHeight(), BufferedImage.TYPE_INT_RGB);
				newBufferedImage.createGraphics().drawImage(bufferedImage, 0, 0, Color.WHITE, null);
				file.getName();
				// write to jpeg file
				ImageIO.write(newBufferedImage, "jpg", new File(image));
				//ImageIO.write(newBufferedImage, "jpg", new File("D:\\DOCS\\CSBC\\CSBC_CONTABLE\\Photos\\"+file.getName()));
			}
			return imageType;
			//System.out.println("Format: " + reader.getFormatName());

		}catch(Exception e){
			  try
	            {
	                FileUtils.copyFile(new File(image), new File((new StringBuilder("D:/CSBC/01-2022/CorruptedImages/")).append(rollno).append("_").append(type).append(".jpg").toString()));
	            }
	            catch(IOException ex)
	            {
	                ex.printStackTrace();
	            }
			  System.out.println((new StringBuilder(String.valueOf(rollno))).append("-").append(image).toString());
			  
			e.printStackTrace();
			return null;
		}

	}

	public static void saveImageJPG(String image,String rollno){
		try{
			String imageType=null;
			File file = new File(image);
			//System.out.println(rollno+"-"+image+" Name="+file.getName());
			//read image file
			BufferedImage  bufferedImage = ImageIO.read(new File(image));
			// create a blank, RGB, same width and height, and a white background
			BufferedImage newBufferedImage = new BufferedImage(bufferedImage.getWidth(),
					bufferedImage.getHeight(), BufferedImage.TYPE_INT_RGB);
			newBufferedImage.createGraphics().drawImage(bufferedImage, 0, 0, Color.WHITE, null);
			file.getName();
			// write to jpeg file
			ImageIO.write(newBufferedImage, "jpg", new File(image));
			//ImageIO.write(newBufferedImage, "jpg", new File("D:\\Projects\\JAVA Projets\\SSBWorkspace\\BPSSCAttendance\\converted_photos\\"+file.getName()));
			//System.out.println("Format: " + reader.getFormatName());

		}catch(Exception e){
			System.out.println("Error occured-"+image);
			e.printStackTrace();
		}

	}

}
