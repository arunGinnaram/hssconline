package com.ttil.dao;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import XMLTransform.XMLTransformer;

public class StickerGeneration {

	public static void main(String[] args){
		StickerGeneration strg=new StickerGeneration();
		//strg.envlopesticker();
		String photoPath="D://CSBC//PHOTOS";
		String xslPath="C:\\Users\\ginna\\Downloads\\CSBCAttendanceWeb\\CSBCAttendanceWeb\\WebContent\\sys";
		String reportsPath="D://CSBC//ROLLNO_STICKERS";
		strg.rollnostickerConstablePhoto(photoPath,xslPath,reportsPath);
		//strg.envlopestickerSteno();
	}
	
	public void rollnostickerConstablePhoto(String Photopath,String xslPath,String reportsPath){
		ResultSet rs=null;
		ResultSet rs1=null;
		Connection conn=null;
		Statement stmt=null;
		Statement stmt1=null;
		String rollno1=null,rollno2=null,rollno3=null,werollno=null,appno="";
		String rollno1_temp=null,rollno2_temp=null,rollno3_temp=null,werollno_temp=null;
		int centercode=0,weexamcode=0;
		String candidatePhoto="";
		String candidateSignEng="";
		String candidateSignHnd="";
		File photoFile=null,sigFile=null,hindiSigFile=null;
		String first_name="";
		int i=0;
		StringBuffer xml=null;
		String reportFormat="pdf";
		String query="";
		String query1="select wecentrecode as centercode,weexamcode from applicants  where   weexamcode=75   group by wecentrecode,weexamcode order by weexamcode,wecentrecode ";
		//String query1="select distinct(wecentrecode) as centercode from attendancesheets where weexamcode in (77)    order by wecentrecode,weexamcode ";
		try{
			conn=DBConnection.getMySQLDatabaseConnection("csbc_ct_02_2022");
			stmt=conn.createStatement();
			stmt1=conn.createStatement();
			rs1=stmt1.executeQuery(query1);
			if(rs1.next()){
				xml = new StringBuffer();
				centercode=rs1.getInt("centercode");
				weexamcode=rs1.getInt("weexamcode");
				
				query="select werollno,transactionid,first_name  from applicants where wecentrecode="+centercode+" and weexamcode="+weexamcode+" and werollno is not null order by werollno  limit 48  ";
				rs=stmt.executeQuery(query);
				i=0; int j=0,k=0,l=0,first_column=0;
				
				
				if(weexamcode==25)
				    xml.append("<datetime>14-03-2021 10AM</datetime>");
				else if(weexamcode==35)
					xml.append("<datetime>14-03-2021 2PM</datetime>");
				else if(weexamcode==31)
					xml.append("<datetime>21-03-2021 10AM</datetime>");
				else if(weexamcode==41)
					xml.append("<datetime>21-03-2021 2PM</datetime>");
				else if(weexamcode==16)
					xml.append("<datetime>28-08-2022 10AM</datetime>");
				else if(weexamcode==26)
					xml.append("<datetime>28-08-2022 10AM</datetime>");
				else if(weexamcode==17)
					xml.append("<datetime>16-10-2022 10AM</datetime>");
				else if(weexamcode==18)
					xml.append("<datetime>21-03-2023 10AM</datetime>");
				else if(weexamcode==75)
					xml.append("<datetime>14-05-2023 </datetime>");
				
				while(rs.next()){
					i++; j++;k++;l++;first_column++;
					
					appno=rs.getString("transactionid");
					first_name=rs.getString("first_name");
					
					candidatePhoto="";
					candidateSignEng="";
					candidateSignHnd="";
					photoFile=null;sigFile=null;hindiSigFile=null;
					
					//candidatePhoto=Photopath+File.separator+appno+"_photo.jpg";
					candidatePhoto=Photopath+File.separator+appno+".jpg";
					
					photoFile=new File(candidatePhoto);
					if(!photoFile.exists()){
						//System.out.println(photoFile.getAbsolutePath());
						try{
							URL url = new URL("http://3.108.242.32:86/ProhCT0222/candidateImages//"+appno+"_photo.jpg");

							InputStream is = url.openStream();
							OutputStream os = new FileOutputStream(candidatePhoto);
							byte[] b = new byte[2048];
							int length;

							while ((length = is.read(b)) != -1) {
								os.write(b, 0, length);
							}
							is.close();
							os.close();
						}catch(Exception e){
							e.printStackTrace();
						}
					}
					
					
					werollno=rs.getString("werollno");
					if(i==1){
						xml.append("<row>");	
					}
					xml.append("<canphoto"+i+">"+candidatePhoto+"</canphoto"+i+">");
					xml.append("<rollno"+i+">"+werollno+"</rollno"+i+">");
					xml.append("<first_name"+i+">"+first_name+"</first_name"+i+">");
					if(i==24){
						xml.append("</row>");
						i=0;
					}
				}
				if(i>=1 && i<=23){
					xml.append("</row>");
				}
				String c="",reportName="";
				c="<root><result>";
				xml.append("</result>");
				xml.append("</root>");
				reportName=centercode+"_"+weexamcode+"_RollnoSticker";
				String x=c+xml;
				System.out.println(x);
				String outPut="";
				try{
					System.out.println("X="+x);
					StringReader rd=new StringReader(x);
					if(reportFormat.length()>=0){
						outPut=new XMLTransformer().GetTransformedString(rd, "pdf", "RollnoStickerA4_CONSTABLES_PHOTO",reportName,xslPath,reportsPath);
					}
				}catch(Exception e){
					e.printStackTrace();
				}
			}

		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	public void envlopesticker(){
		ResultSet rs=null;
		ResultSet rs1=null;
		Connection conn=null;
		Statement stmt=null;
		Statement stmt1=null;
		String rollno1=null,rollno2=null,rollno3=null,werollno=null;
		String rollno1_temp=null,rollno2_temp=null,rollno3_temp=null,werollno_temp=null;
		int centercode;
		int i=0;
		StringBuffer xml=null;
		String reportFormat="pdf";
		String query="";
		String query1="select distinct(wecentrecode) as centercode from applicants where wecentrecode is not null AND wecentrecode IN (1227) order by wecentrecode ";
		try{
			conn=DBConnection.getMySQLDatabaseConnection();
			stmt=conn.createStatement();
			stmt1=conn.createStatement();
			rs1=stmt1.executeQuery(query1);
			String CentreCode="",NameAddressofCentre="";
			while(rs1.next()){
				xml = new StringBuffer();
				centercode=rs1.getInt("centercode");
				query="select wecentrecode,wecentre from applicants where wecentrecode="+centercode+" group by wecentrecode,wecentre";
				System.out.println(query);
				rs=stmt.executeQuery(query);
				i=0;
				while(rs.next()){
					CentreCode=rs.getString("wecentrecode");
					NameAddressofCentre=rs.getString("wecentre").replaceAll("&", " and ");
					xml.append("<row>");	
					xml.append("<CentreCode>"+CentreCode+"</CentreCode>");
					xml.append("<CentreCode1>"+CentreCode+"</CentreCode1>");
					xml.append("<NameAddressofCentre>"+NameAddressofCentre+"</NameAddressofCentre>");
					xml.append("<NameAddressofCentre1>"+NameAddressofCentre+"</NameAddressofCentre1>");
					xml.append("</row>");
				}
				String xslPath="D://Projects//JAVA Projets//SSBWorkspace//BPSSCAttendance//sys";
				String reportsPath="D://Projects//JAVA Projets//SSBWorkspace//BPSSCAttendance//Reports";	
				String c="",reportName="";
				c="<root><result>";
				xml.append("</result>");
				xml.append("</root>");
				reportName=centercode+"_EnvelopSticker";
				String x=c+xml;
				System.out.println(x);
				String outPut="";
				try{
					System.out.println("X="+x);
					StringReader rd=new StringReader(x);
					if(reportFormat.length()>=0){
						//outPut=new XMLTransformer().GetTransformedString(rd, "pdf", "HeadingStickerA4",reportName);
					}
				}catch(Exception e){
					e.printStackTrace();
				}
			}

		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void rollnosticker(){
		ResultSet rs=null;
		ResultSet rs1=null;
		Connection conn=null;
		Statement stmt=null;
		Statement stmt1=null;
		String rollno1=null,rollno2=null,rollno3=null,werollno=null;
		String rollno1_temp=null,rollno2_temp=null,rollno3_temp=null,werollno_temp=null;
		int centercode;
		int i=0;
		StringBuffer xml=null;
		String reportFormat="pdf";
		String query="";
		String query1="select distinct(wecentrecode) as centercode from applicants  where wecentrecode is not null and wecentrecode IN (1003,5003)  order by wecentrecode ";
		try{
			conn=DBConnection.getMySQLDatabaseConnection();
			stmt=conn.createStatement();
			stmt1=conn.createStatement();
			rs1=stmt1.executeQuery(query1);
			while(rs1.next()){
				xml = new StringBuffer();
				centercode=rs1.getInt("centercode");
				query="select werollno as werollno  from applicants where wecentrecode='"+centercode+"' and werollno is not null and new_admitcard is not null order by werollno  ";
				rs=stmt.executeQuery(query);
				i=0;
				while(rs.next()){
					i++;
					if(i==1){
						xml.append("<row>");	
					}
					werollno=rs.getString("werollno");
					xml.append("<rollno"+i+">"+werollno+"</rollno"+i+">");
					if(i==3){
						xml.append("</row>");
						i=0;
					}
				}
				if(i==2 || i==1){
					xml.append("</row>");
				}
				String c="",reportName="";
				c="<root><result>";
				xml.append("</result>");
				xml.append("</root>");
				reportName=centercode+"_RollnoSticker";
				String x=c+xml;
				System.out.println(x);
				String outPut="";
				try{
					System.out.println("X="+x);
					StringReader rd=new StringReader(x);
					if(reportFormat.length()>=0){
						//outPut=new XMLTransformer().GetTransformedString(rd, "pdf", "RollnoStickerA4",reportName);
					}
				}catch(Exception e){
					e.printStackTrace();
				}
			}

		}catch(Exception e){
			e.printStackTrace();
		}
	}


	public void rollnostickerSteno(){
		ResultSet rs=null;
		ResultSet rs1=null;
		Connection conn=null;
		PreparedStatement pstmt=null;
		Statement stmt1=null;
		String rollno1=null,rollno2=null,rollno3=null,werollno=null;
		String rollno1_temp=null,rollno2_temp=null,rollno3_temp=null,werollno_temp=null;
		int centercode;
		int i=0;
		StringBuffer xml=null;
		String reportFormat="pdf";
		String query="";
		String query2="select typing_date,typing_reportingtime,typing_lab,typing_venue,max(typing_sheetno) as max_sheetno,count(*) as alloted_count from applicants where typing_date is not null   and typing_rollno is not null and   typing_date='24-08-2019' group by typing_date,typing_reportingtime,typing_lab,typing_venue";
		query="select typing_rollno as werollno  from applicants where  typing_rollno is not null  and typing_date=? and typing_reportingtime=?  and typing_lab=? order by typing_rollno ";
		try{
			conn=DBConnection.getMySQLDatabaseConnection();
			stmt1=conn.createStatement();
			pstmt=conn.prepareStatement(query);
			rs1=stmt1.executeQuery(query2);
			String typing_date="",typing_lab="",typing_reportingtime="";
			while(rs1.next()){
				xml = new StringBuffer();

				typing_date=rs1.getString("typing_date");
				typing_lab=rs1.getString("typing_lab");
				typing_reportingtime=rs1.getString("typing_reportingtime");
				pstmt.setString(1, typing_date);
				pstmt.setString(2, typing_reportingtime);
				pstmt.setString(3, typing_lab);
				rs=pstmt.executeQuery();
				i=0;
				while(rs.next()){
					i++;
					if(i==1){
						xml.append("<row>");	
					}
					werollno=rs.getString("werollno");
					xml.append("<rollno"+i+">"+werollno+"</rollno"+i+">");
					if(i==3){
						xml.append("</row>");
						i=0;
					}
				}
				if(i==2 || i==1){
					xml.append("</row>");
				}
				String c="",reportName="";
				c="<root><result>";
				xml.append("</result>");
				xml.append("</root>");
				//reportName=centercode+"_RollnoSticker";
				if(typing_reportingtime!=null)
					typing_reportingtime=typing_reportingtime.replaceAll(":", "");
				reportName=typing_date+"_"+typing_lab+"_"+typing_reportingtime+"Steno_RollnoSticker";

				String x=c+xml;
				System.out.println(x);
				String outPut="";
				try{
					System.out.println("X="+x);
					StringReader rd=new StringReader(x);
					if(reportFormat.length()>=0){
						//outPut=new XMLTransformer().GetTransformedString(rd, "pdf", "RollnoStickerA4",reportName);
					}
				}catch(Exception e){
					e.printStackTrace();
				}
			}

		}catch(Exception e){
			e.printStackTrace();
		}
	}


	public void envlopestickerSteno(){
		ResultSet rs=null;
		ResultSet rs1=null;
		Connection conn=null;
		Statement stmt=null;
		Statement stmt1=null;
		String rollno1=null,rollno2=null,rollno3=null,werollno=null;
		String rollno1_temp=null,rollno2_temp=null,rollno3_temp=null,werollno_temp=null;
		int centercode;
		int i=0;
		StringBuffer xml=null;
		String reportFormat="pdf";
		String query="";
		String query1="select typing_date,typing_reportingtime,typing_lab,typing_venue,max(typing_sheetno) as max_sheetno,count(*) as alloted_count from applicants where typing_date is not null   and typing_rollno is not null and   typing_date='24-08-2019' group by typing_date,typing_reportingtime,typing_lab,typing_venue";
		try{
			conn=DBConnection.getMySQLDatabaseConnection();
			stmt=conn.createStatement();
			stmt1=conn.createStatement();
			rs1=stmt1.executeQuery(query1);
			String CentreCode="",NameAddressofCentre="";
			String typing_date="",typing_lab="",typing_reportingtime="";
			while(rs1.next()){
				xml = new StringBuffer();
				typing_date=rs1.getString("typing_date");
				typing_lab=rs1.getString("typing_lab");
				typing_reportingtime=rs1.getString("typing_reportingtime");
				xml.append("<row>");	
				xml.append("<CentreDate>"+typing_date+"</CentreDate>");
				xml.append("<CentreTime>"+typing_reportingtime+"</CentreTime>");
				xml.append("<NameAddressofCentre>"+typing_lab+"</NameAddressofCentre>");
				xml.append("</row>");
				String c="",reportName="";
				c="<root><result>";
				xml.append("</result>");
				xml.append("</root>");
				if(typing_reportingtime!=null)
					typing_reportingtime=typing_reportingtime.replaceAll(":", "");
				reportName=typing_date+"_"+typing_lab+"_"+typing_reportingtime+"_EnvelopSticker";
				String x=c+xml;
				System.out.println(x);
				String outPut="";
				try{
					System.out.println("X="+x);
					StringReader rd=new StringReader(x);
					if(reportFormat.length()>=0){
						//outPut=new XMLTransformer().GetTransformedString(rd, "pdf", "HeadingStickerStenoA4",reportName);
					}
				}catch(Exception e){
					e.printStackTrace();
				}
			}

		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
