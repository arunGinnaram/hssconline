package com.ttil.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ttil.dao.AttendanceGenerationConstable;

public class ResultsServlet  extends HttpServlet {

	private static final long serialVersionUID = 4267945957957617573L;

	public void dopost(HttpServletRequest req,HttpServletResponse res)  
			throws ServletException,IOException
			{

		this.service(req, res);
			}

	public void service(HttpServletRequest request,HttpServletResponse res) throws ServletException,IOException
	{
		RequestDispatcher rd=null;
		String path=this.getServletContext().getRealPath("path.properties");
		String xslPath=this.getServletContext().getRealPath("sys");
		String photoPath=null, signPath=null, signHindiPath=null, reportsPath=null;
	    String dbhost = null;
        String dbusername = null;
        String dbpassword = null;
        String dbname = null;
		//String reportsPath=this.getServletContext().getRealPath("Reports");
		//String photoPath=this.getServletContext().getRealPath("candidate_photos");
		//String signPath=this.getServletContext().getRealPath("candidate_sign");
		//String signHindiPath=this.getServletContext().getRealPath("candidate_sign_hindi");
		String imagesPath=this.getServletContext().getRealPath("images");
		int weexamcode=0,wecentrecode=0,wesheetno=0;
		String werollno=request.getParameter("werollno");
		String examcode=request.getParameter("examcode");
		String centrecode=request.getParameter("centrecode");
		Properties props = new Properties();
		
		try
		{
			props.load(new FileInputStream(path));
			photoPath=props.getProperty("photoPath");
			signPath=props.getProperty("engSignPath");
			signHindiPath=props.getProperty("hindiSignPath");
			reportsPath=props.getProperty("reportsPath");
			dbhost = props.getProperty("dbhost");
            dbusername = props.getProperty("dbusername");
            dbpassword = props.getProperty("dbpassword");
            dbname = props.getProperty("dbname");
		}
		catch(Exception e)
		{
			System.out.println("Unalble to load Database connection property file");
		}
		
		if(examcode==null || "".equalsIgnoreCase(examcode) || "0".equalsIgnoreCase(examcode))
		{
			weexamcode=0;
		}else{
			weexamcode=Integer.parseInt(examcode);
		}
		if(centrecode==null || "".equalsIgnoreCase(centrecode) || "0".equalsIgnoreCase(centrecode))
		{
			wecentrecode=0;
		}else{
			wecentrecode=Integer.parseInt(centrecode);
		}
		if(centrecode==null || "".equalsIgnoreCase(centrecode) || "0".equalsIgnoreCase(centrecode))
		{
			wecentrecode=0;
		}else{
			wecentrecode=Integer.parseInt(centrecode);
		}
		String sheetno=request.getParameter("sheetno");
		if(sheetno==null || "".equalsIgnoreCase(sheetno) || "0".equalsIgnoreCase(sheetno))
		{
			wesheetno=0;
		}else{
			wesheetno=Integer.parseInt(sheetno);
		}
		
		
		
		AttendanceGenerationConstable attgen = new AttendanceGenerationConstable();
     String output = attgen.bihar_we_attendanceConstable(photoPath, signPath, signHindiPath, imagesPath, xslPath, reportsPath, weexamcode, wecentrecode, wesheetno, werollno, dbhost, dbusername, dbpassword, dbname);
 //String output = attgen.bihar_we_attendanceConstableByRollnos(photoPath, signPath, signHindiPath, imagesPath, xslPath, reportsPath, weexamcode, wecentrecode, wesheetno, werollno);
	       
		if(output!=null && !"".equalsIgnoreCase(output)){

			ServletOutputStream out=null;
			if(output!=null){
				File file=new File(reportsPath+"/"+output);
				out = res.getOutputStream();
				res.setContentType("application/pdf");
				res.setHeader("Content-disposition", "attachment; filename="+output );

				InputStream in = new FileInputStream(file);
				int bit = 256;
				try {
					while ((bit) >= 0) {
						bit = in.read();
						out.write(bit);
					}

				} catch (IOException ioe) {
					ioe.printStackTrace();
					ioe.printStackTrace(System.out);
				}

				in.close();
			}

		}
	}

}
