package com.ttil.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

	public Connection getDatabaseConnection()
	{
		Connection conn=null;
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			conn = DriverManager.getConnection("jdbc:odbc:bpssc1","bhopalpet2017","bhopalpet2017");
			if(conn!=null)
			{
				return conn;
			}
			else
			{
				return null;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return conn;
	}

	public  static Connection getMySQLDatabaseConnection()
	{
		Connection conn=null;
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			//conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/bpssc_live","root","");  
			conn=DriverManager.getConnection("jdbc:mysql://bpsscrds.cof0fc3mnt2s.ap-southeast-1.rds.amazonaws.com:3306/csbc_ct_hg_2020","bpssc_ttl","bpssc_ttil_1234");
		}catch(Exception e){ System.out.println(e);}  
		return conn;
	}

	public  static Connection getMySQLDatabaseConnection(String dbname)
	{
		Connection conn=null;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			if(dbname != null && dbname.equalsIgnoreCase("csbc_01_2022"))
			{
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3390/csbc_01_2022", "root", "admin@123");
			} else if(dbname != null && dbname.equalsIgnoreCase("csbc_ct_01_2022"))
			{
				conn = DriverManager.getConnection("jdbc:mysql://applicationcsbcv4.cm0bksyl0mvc.ap-south-1.rds.amazonaws.com:3390/csbc_ct_01_2022", "csbc_ttl", "J-B)h6ehKN4");
			}else if(dbname != null && dbname.equalsIgnoreCase("csbc_ct_02_2022"))
			{
				conn = DriverManager.getConnection("jdbc:mysql://applicationcsbcv4.cm0bksyl0mvc.ap-south-1.rds.amazonaws.com:3390/csbc_ct_02_2022", "csbc_ttl", "J-B)h6ehKN4");
			} else if(dbname != null && dbname.equalsIgnoreCase("csbc_ct_02_2021"))
			{
				conn = DriverManager.getConnection("jdbc:mysql://applicationcsbcv4.cm0bksyl0mvc.ap-south-1.rds.amazonaws.com:3390/csbc_ct_02_2021", "csbc_ttl", "J-B)h6ehKN4");
			} else if(dbname != null && dbname.equalsIgnoreCase("csbc_ct_05_2020"))
			{
				conn = DriverManager.getConnection("jdbc:mysql://application01v3.cm0bksyl0mvc.ap-south-1.rds.amazonaws.com:3390/csbc_ct_05_2020", "csbc_ttl", "J-B)h6ehKN4");
			} else if(dbname != null && dbname.equalsIgnoreCase("csbc_fireman_01_2021"))
			{
				conn = DriverManager.getConnection("jdbc:mysql://application01v3.cm0bksyl0mvc.ap-south-1.rds.amazonaws.com:3390/csbc_fireman_01_2021", "csbc_ttl", "J-B)h6ehKN4");
			} else
			{
				conn = DriverManager.getConnection("jdbc:mysql://application02.cof0fc3mnt2s.ap-southeast-1.rds.amazonaws.com:3390/csbc_ct_hg_2020", "bpssc_ttl", "K9beW(vqP3F");
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return conn;
	}
	public static Connection getMySQLDatabaseConnectionPoperty(String dbhost, String dbusername, String dbpassword, String dbname)
	{
		Connection conn = null;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection((new StringBuilder("jdbc:mysql://")).append(dbhost).append("/").append(dbname).toString(), dbusername, dbpassword);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return conn;
	}
}
